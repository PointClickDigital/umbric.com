<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/steps" only-nested=true}}
{{inner-blocks allowed-blocks=["yoast/step"]}}
