<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://pointclick.digital
 * @since             1.0.0
 * @package           Ato_pcd
 *
 * @wordpress-plugin
 * Plugin Name:       Advanced Theme Options for Umbric.com
 * Plugin URI:        https://pointclick.digital
 * Description:       Advanced Theme Options adds support For Custom Post Types which can be easily migrated as is not                           theme specific  
 * Version:           1.0.0
 * Author:            PointClick Digital LLC
 * Author URI:        https://pointclick.digital
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ato_pcd
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'ATO_PCD_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-ato_pcd-activator.php
 */
function activate_ato_pcd() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-ato_pcd-activator.php';
	Ato_pcd_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-ato_pcd-deactivator.php
 */
function deactivate_ato_pcd() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-ato_pcd-deactivator.php';
	Ato_pcd_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_ato_pcd' );
register_deactivation_hook( __FILE__, 'deactivate_ato_pcd' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-ato_pcd.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_ato_pcd() {

	$plugin = new Ato_pcd();
	$plugin->run();

}
run_ato_pcd();
