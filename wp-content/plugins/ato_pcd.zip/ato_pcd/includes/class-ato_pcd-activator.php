<?php

/**
 * Fired during plugin activation
 *
 * @link       https://pointclick.digital
 * @since      1.0.0
 *
 * @package    Ato_pcd
 * @subpackage Ato_pcd/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Ato_pcd
 * @subpackage Ato_pcd/includes
 * @author     PointClick Digital LLC <hello@pointclick.digital>
 */
class Ato_pcd_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
