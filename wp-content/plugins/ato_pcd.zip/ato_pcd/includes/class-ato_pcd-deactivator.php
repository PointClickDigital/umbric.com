<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://pointclick.digital
 * @since      1.0.0
 *
 * @package    Ato_pcd
 * @subpackage Ato_pcd/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Ato_pcd
 * @subpackage Ato_pcd/includes
 * @author     PointClick Digital LLC <hello@pointclick.digital>
 */
class Ato_pcd_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
