<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://pointclick.digital
 * @since      1.0.0
 *
 * @package    Ato_pcd
 * @subpackage Ato_pcd/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Ato_pcd
 * @subpackage Ato_pcd/admin
 * @author     PointClick Digital LLC <hello@pointclick.digital>
 */
class Ato_pcd_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}
	
	public function add_plugin_admin_menu() {

    /*
     * Add settings page for this plugin to the Settings menu.
     *
     */
    add_options_page( 'Advanced Theme Options by PointClick Digital', 'Advanced Theme Options', 'manage_options', $this->plugin_name, array($this, 'display_plugin_setup_page')
    );
}

 /**
 * Add settings action link to the plugins page.
 *
 * @since    1.0.0
 */

public function add_action_links( $links ) {
    
   $settings_link = array(
    '<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_name ) . '">' . __('Settings', $this->plugin_name) . '</a>',
   );
   return array_merge(  $settings_link, $links );

}



	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ato_pcd_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ato_pcd_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/ato_pcd-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ato_pcd_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ato_pcd_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/ato_pcd-admin.js', array( 'jquery' ), $this->version, false );

	}

}


add_action( 'init', 'pcd_services_register_post_type' );
function pcd_services_register_post_type() {
	$args = [
		'label'  => esc_html__( 'Services', 'text-domain' ),
		'labels' => [
			'menu_name'          => esc_html__( 'Services', 'pcd-services' ),
			'name_admin_bar'     => esc_html__( 'Services', 'pcd-services' ),
			'add_new'            => esc_html__( 'Add Service', 'pcd-services' ),
			'add_new_item'       => esc_html__( 'Add new Service', 'pcd-services' ),
			'new_item'           => esc_html__( 'New Service', 'pcd-services' ),
			'edit_item'          => esc_html__( 'Edit Service', 'pcd-services' ),
			'view_item'          => esc_html__( 'View Service', 'pcd-services' ),
			'update_item'        => esc_html__( 'View Service', 'pcd-services' ),
			'all_items'          => esc_html__( 'All Services', 'pcd-services' ),
			'search_items'       => esc_html__( 'Search Services', 'pcd-services' ),
			'parent_item_colon'  => esc_html__( 'Parent Service', 'pcd-services' ),
			'not_found'          => esc_html__( 'No Services found', 'pcd-services' ),
			'not_found_in_trash' => esc_html__( 'No Services found in Trash', 'pcd-services' ),
			'name'               => esc_html__( 'Services', 'pcd-services' ),
			'singular_name'      => esc_html__( 'Service', 'pcd-services' ),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => false,
		'has_archive'         => 'services',
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => true,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-superhero',
		'supports' => [
			'title',
			'editor',
			'thumbnail',
			'trackbacks',
			'custom-fields',
			'revisions',
			'page-attributes',
		],
		'taxonomies' => [
			'post_tag',
			'pcd_srvc',
		],
		'rewrite' => [ 'slug' => '', 'with_front' => false ]
	];

	register_post_type( 'services', $args );
}
if ( ! function_exists( 'pcd_taxonomy' ) ) {

// Register Custom Taxonomy
function pcd_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Service Types', 'Taxonomy General Name', 'srvc-type' ),
		'singular_name'              => _x( 'Service Type', 'Taxonomy Singular Name', 'srvc-type' ),
		'menu_name'                  => __( 'Service Types', 'srvc-type' ),
		'all_items'                  => __( 'All Service Types', 'srvc-type' ),
		'parent_item'                => __( 'Parent Service Types', 'srvc-type' ),
		'parent_item_colon'          => __( 'Parent Service Types:', 'srvc-type' ),
		'new_item_name'              => __( 'New Service Type Name', 'srvc-type' ),
		'add_new_item'               => __( 'Add New Service Type', 'srvc-type' ),
		'edit_item'                  => __( 'Edit Service Type', 'srvc-type' ),
		'update_item'                => __( 'Update Service Type', 'srvc-type' ),
		'view_item'                  => __( 'View Service Type', 'srvc-type' ),
		'separate_items_with_commas' => __( 'Separate service type with commas', 'srvc-type' ),
		'add_or_remove_items'        => __( 'Add or remove service type', 'srvc-type' ),
		'choose_from_most_used'      => __( 'Choose from the most used service types', 'srvc-type' ),
		'popular_items'              => __( 'Popular Service Types', 'srvc-type' ),
		'search_items'               => __( 'Search Service Types', 'srvc-type' ),
		'not_found'                  => __( 'No Service Types Found', 'srvc-type' ),
		'no_terms'                   => __( 'No Service Types', 'srvc-type' ),
		'items_list'                 => __( 'Service Types List', 'srvc-type' ),
		'items_list_navigation'      => __( 'Service Types list navigation', 'srvc-type' ),
	);
	$rewrite = array(
		'slug'                       => 'service-type',
		'with_front'                 => true,
		'hierarchical'               => false,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => false,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'rewrite'                    => $rewrite,
		'show_in_rest'               => true,
		'rest_controller_class'      => 'WP_REST_PCD_SRVC_TPYE_Controller',
	);
	register_taxonomy( 'pcd_srvc', array( 'pcd_services' ), $args );

}
add_action( 'init', 'pcd_taxonomy', 0 );

}




add_action( 'init', 'pcd_tutorials' );
function pcd_tutorials() {
	$args = [
		'label'  => esc_html__( 'Tutorials', 'text-domain' ),
		'labels' => [
			'menu_name'          => esc_html__( 'Tutorials', 'tutorials' ),
			'name_admin_bar'     => esc_html__( 'Tutorial', 'tutorials' ),
			'add_new'            => esc_html__( 'Add Tutorial', 'tutorials' ),
			'add_new_item'       => esc_html__( 'Add new Tutorial', 'tutorials' ),
			'new_item'           => esc_html__( 'New Tutorial', 'tutorials' ),
			'edit_item'          => esc_html__( 'Edit Tutorial', 'tutorials' ),
			'view_item'          => esc_html__( 'View Tutorial', 'tutorials' ),
			'update_item'        => esc_html__( 'View Tutorial', 'tutorials' ),
			'all_items'          => esc_html__( 'All Tutorials', 'tutorials' ),
			'search_items'       => esc_html__( 'Search Tutorials', 'tutorials' ),
			'parent_item_colon'  => esc_html__( 'Parent Tutorial', 'tutorials' ),
			'not_found'          => esc_html__( 'No Tutorials found', 'tutorials' ),
			'not_found_in_trash' => esc_html__( 'No Tutorials found in Trash', 'tutorials' ),
			'name'               => esc_html__( 'Tutorials', 'tutorials' ),
			'singular_name'      => esc_html__( 'Tutorial', 'tutorials' ),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => true,
		'has_archive'         => 'tutorials',
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => false,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-awards',
		'supports' => [
			'title',
			'editor',
			'thumbnail',
			'revisions',
			'page-attributes',
		],
		'taxonomies' => [
			'category',
			'tag',
		],
		'rewrite' => true
	];

	register_post_type( 'tutorial', $args );
}

/**
 * Add a widget to the dashboard.
 *
 * This function is hooked into the 'wp_dashboard_setup' action below.
 */



function wporg_add_dashboard_widgets() {
    wp_add_dashboard_widget(
        'wporg_dashboard_widget',                          // Widget slug.
        esc_html__( 'Support When You Need It', 'wporg' ), // Title.
        'wporg_dashboard_widget_render'                    // Display function.
    ); 
	
	 // Remove Welcome panel
    remove_action( 'welcome_panel', 'wp_welcome_panel' );
    // Remove the rest of the dashboard widgets
    remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
    remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
    remove_meta_box( 'health_check_status', 'dashboard', 'normal' );
    remove_meta_box( 'dashboard_right_now', 'dashboard', 'normal' );
    remove_meta_box( 'dashboard_activity', 'dashboard', 'normal');
	
}
add_action( 'wp_dashboard_setup', 'wporg_add_dashboard_widgets' );
 
/**
 * Create the function to output the content of our Dashboard Widget.
 */
function wporg_dashboard_widget_render() {
	?>
    <div style="display:grid;justify-content:space-between;grid-template-columns:repeat(auto-fit,minmax(50%,1fr));grid-template-rows:1fr;grid-gap:10px;">
        <div>
            <img src="https://pointclick.digital/wp-content/uploads/2020/04/pointclick_logo_smaller.png" style="border:0px solid #ccc;padding:2px;">
        </div>
        <div>
            <h2>Have An Idea For A Project?</h2>
            We're <strong>available</strong> to help fulfill your needs ! If you need anything at all, drop us a line!
            <ul>
                <li>(804) 459-8758</li>
                <li><a href="mailto:hello@pointclick.digital">hello@pointclick.digital</a></li>
            </ul>
			<button onclick="window.location.href='https://support.pointclick.digital'" class="dash-btn">Support</button>
			<button onclick="window.location.href='https://pointclick.digital/contact-us'" class="dash-btn">Quotes</button>
        </div>
    </div>
    <?php
}
